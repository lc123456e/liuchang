/*! ----------------------------------------------------------------------------
 * @file	compiler.h
 * @brief   Compiler abstraction helpers used by the merged UWB firmware.
 */
#ifndef COMPILER_H_
#define COMPILER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <assert.h>
#include "delay.h"

#ifndef CLOCKS_PER_SEC
#define CLOCKS_PER_SEC 1000
#endif

#ifndef __bool_true_false_are_defined
#ifndef __cplusplus
//typedef unsigned char bool;
#endif
#define true 1
#define false 0
#define __bool_true_false_are_defined 1
#endif

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#ifndef __align4
#if defined(__CC_ARM)
#define __align4 __align(4)
#else
#define __align4 __attribute__((aligned (4)))
#endif
#endif

#ifndef __weak
#if defined(__CC_ARM)
#define __weak __weak
#else
#define __weak __attribute__((weak))
#endif
#endif

#ifndef __always_inline
#if defined(__CC_ARM)
#define __always_inline __forceinline
#else
#define __always_inline __attribute__((always_inline))
#endif
#endif

#ifdef __cplusplus
}
#endif

#endif /* COMPILER_H_ */
