#include "led.h"
#include "delay.h"

u8 LED0=0;
	
void GPIO_Configuration(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;					 //����GPIO�ṹ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);	//ʹ��PC�˿�ʱ��	
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);  
	
	// Enable GPIO used for LEDs
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// Enable GPIO used for Buzzer
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	// Enable GPIO used for BQ
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	// EXTON
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}
 
void Buzzer_speak(void)
{
	int j=0;
	for(j=0;j<50;j++)
	{
			Buzzer_H;	
			Sleep(1);
			Buzzer_L;	
			Sleep(1);
	}		
}
void PB4_Configuration(u8 num)
{
	GPIO_InitTypeDef  GPIO_InitStructure;					 //����GPIO�ṹ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	//ENABLE PortB Clock	
	
	if(num == 1)
	{
		// LIS3DH INT
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOB, &GPIO_InitStructure);	
	}
	if(num == 0)
	{
		// Power Pin
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOB, &GPIO_InitStructure);
		GPIO_SetBits(GPIOB, GPIO_Pin_4);		
	}
}


void led_off (led_t led)
{
	switch (led)
	{
	case LED_PC6:
		GPIO_ResetBits(GPIOB, GPIO_Pin_6);
		break;
	case LED_PC7:
		GPIO_ResetBits(GPIOB, GPIO_Pin_7);
		break;

	case LED_ALL:
		GPIO_ResetBits(GPIOB, GPIO_Pin_6 | GPIO_Pin_7);
		break;
	default:
		// do nothing for undefined led number
		break;
	}
}

void led_on (led_t led)
{
	switch (led)
	{
	case LED_PC6:
		GPIO_SetBits(GPIOB, GPIO_Pin_6);
		break;
	case LED_PC7:
		GPIO_SetBits(GPIOB, GPIO_Pin_7);
		break;

	case LED_ALL:
		GPIO_SetBits(GPIOB, GPIO_Pin_6 | GPIO_Pin_7);
		break;
	default:
		// do nothing for undefined led number
		break;
	}
}


void led1_dw(u8 m)
{
	if(m==1) GPIO_ResetBits(GPIOB,GPIO_Pin_7);			//��PB7��0	 Ϩ��LED��
	else GPIO_SetBits(GPIOB,GPIO_Pin_7);			      //��PB7��1	 ����LED��
}

void led0_dw(u8 m)
{
	if(m==1) GPIO_ResetBits(GPIOB,GPIO_Pin_6);			//��PB6��0	 Ϩ��LED��
	else GPIO_SetBits(GPIOB,GPIO_Pin_6);			      //��PB6��1	 ����LED��
}
