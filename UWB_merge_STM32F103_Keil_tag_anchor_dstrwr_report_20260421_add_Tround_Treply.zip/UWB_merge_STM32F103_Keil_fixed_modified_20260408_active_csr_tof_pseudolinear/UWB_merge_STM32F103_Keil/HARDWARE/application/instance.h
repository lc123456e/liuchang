/*! ----------------------------------------------------------------------------
 *  @file    instance.h
 *  @brief   DecaWave header for application level instance
 *
 * @attention
 *
 * Copyright 2013 (c) DecaWave Ltd, Dublin, Ireland.
 *
 * All rights reserved.
 *
 * @author DecaWave
 */
#ifndef INSTANCE_H_
#define INSTANCE_H_

#ifdef __cplusplus
extern "C" {
#endif


#include "application_definitions.h"
#include "port.h"
#include "deca_types.h"
#include "deca_device_api.h"
#include "tdma_handler.h"

typedef struct
{
	uint8 valid;//ڵЧǣ1 = ڵݿ / ߣ0 = Ч / 
	uint16 nodeShortAddr;//UWB ڵ̵ַڵΨһ ֤š IP
	uint64 currentTxTs;//ǰʱڵһηźŵʱ̣UWB Ӳʱӣ
	uint64 previousTxTs;//һηʱڼ㷢ͼʱƯ
	uint64 masterRxTs;//ڵʱڵ㣨ԭ㣩յڵźŵʱ
	uint64 previousMasterRxTs;//һڵʱʱ
	uint64 neighborRxTs[UWB_LIST_SIZE];//ھӽʱ飺¼ڵյÿھźŵʱ
	uint64 previousneighborRxTs[UWB_LIST_SIZE];//һʱھӽʱ飺¼ڵյÿھźŵʱ
	uint8 neighborValid[UWB_LIST_SIZE];//ھЧ飺Ӧλ 1 = ܺǸھֱͨ
	int32 csrQ16;//ʱƵʱȣQ16 ڵʱڵʱӵƵʱֵ1L<<16  1.0ȫͬ
	uint8 csrValid;//ʱӲЧǣ1=csrQ16 
	int32 relPosMm[3];//飺[0]=X, [1]=Y, [2]=Zλףڵ㣨ԭ㣩
	uint8 positionValid;//λЧǣ1=relPosMm 
	uint32 lastUpdateMs;//ʱ¼ڵλ / ״̬ʲôʱˢµģжǷڣ
} mesh_node_cache_t;

// ###########################################################################
//  UWB λϵͳ ȫֺʵṹ
//  ã浱ǰ豸 ״̬áշϢʱMesh硢ꡢCSR
//  ϵͳġԡкҪдṹ
// ###########################################################################
typedef struct
{
	// ========================= ϵͳ״̬ ================================
    // ǰ豸ģʽê ANCHOR / ǩ TAG
    INST_MODE mode;				        //instance mode (tag or anchor)
	// ״̬ǰ״̬ա͡ࡢȴʼȣ
    INST_STATES testAppState ;			//state machine - current state
	// ״̬һҪл״̬
    INST_STATES nextState ;				//state machine - next state
	// ״̬һ״̬ڻˡԡ쳣ָ
    INST_STATES previousState ;			//state machine - previous state

// ======================== DW1000 Ӳ =============================
    // DW1000 ŵãƵʡӡʣ
	dwt_config_t    configData ;	//DW1000 channel configuration
	// DW1000 书ãŵֵ
	dwt_txconfig_t  configTX ;		//DW1000 TX power configuration
	// ʱӲʱڲྫУ׼
	uint16			txAntennaDelay ; //DW1000 TX antenna delay
	// ʱӲʱڲྫУ׼
	uint16			rxAntennaDelay ; //DW1000 RX antenna delay
	// ĬʱֵδУ׼ʱʹã
	uint16 			defaultAntennaDelay; //reasonable estimate of DW1000 TX/RX antenna delay
	// ʱǷ޸ı־0=δ޸ģ1=޸ģ
    uint8 antennaDelayChanged;
	// ============================ MAC 繦 ================================
    // ֡ʹܣֻĿַԼ֡
    uint8 frameFilteringEnabled ;	//frame filtering is enabled
// ============================ ־ӡ ================================
    // LCD Ļʹܱ־
    uint8 lcdEnabled;
		// ȫܴӡأϢ
    uint8 canPrintInfo;	  //only print to usb and/or LCD display when TRUE
		//  LCD Ļӡ
    uint8 canPrintLCD;
		//  USB ӡ
    uint8 canPrintUSB;

	// ======================== շʱ򡢳ʱʱ =============================
    //  RANGING_INIT Ϣʱ
	uint64 rnginitReplyDelay;
	//  FINAL Ϣʱ
	uint64 finalReplyDelay;
	//  FINAL ʱ΢뵥λ
	uint64 finalReplyDelay_us;
	//  RESP Ϣʱ
	uint64 respReplyDelay;
	//  POLL ȴظĳʱʱ䣨΢뵥λ
	uint16 durationPollTimeout_nus;		//rx timeout duration after tx poll
	 //  POLL ȴظĳʱʱ䣨룩
	uint16 durationPollTimeout_ms;		//rx timeout duration after tx poll
	//  FINAL ȴظĳʱʱ䣨룩
	uint16 durationFinalTimeout_ms;     //rx timeout duration after tx final
// BLINK Ϣɳʱ룩
	uint32 durationBlinkTxDoneTimeout_ms;   	//tx done timeout after tx blink
	// RANGING_INIT Ϣɳʱ룩
	uint32 durationRngInitTxDoneTimeout_ms;   	//tx done timeout after tx rng_init
	// POLL Ϣɳʱ룩
	uint32 durationPollTxDoneTimeout_ms;   		//tx done timeout after tx poll
	// RESP Ϣɳʱ룩
	uint32 durationRespTxDoneTimeout_ms;   		//tx done timeout after tx resp
	// FINAL Ϣɳʱ룩
	uint32 durationFinalTxDoneTimeout_ms;   	//tx done timeout after tx final
	// REPORT Ϣɳʱ룩
	uint32 durationReportTxDoneTimeout_ms;   	//tx done timeout after tx report
	// SYNC Ϣɳʱ룩
	uint32 durationSyncTxDoneTimeout_ms;   		//tx done timeout after tx sync
// UWB 豸ͨųʱʱûյжʧ
	uint32 durationUwbCommTimeout_ms;			//how long to wait before changing UWB_LIST_TYPE if we haven't communicated with or received an information about a UWB in a while
// ģʽ£ȴ RANGING_INIT Ϣĳʱ
	uint32 durationWaitRangeInit_ms;			//discovery mode WAIT_RNG_INIT duration
// TDMA ʱ϶ʱ΢룩
	uint64 durationSlotMax_us;		// longest anticipated time required for a slot based on UWB_LIST_SIZE and S1 switch settings
// ӳٷ͵ʱ32λ
	uint32 delayedReplyTime;		// delayed reply time of delayed TX message - high 32 bits

   // ======================== ֡ʱԤ㣨Żܣ =========================
    // ֡ķʱԤ㣨΢룩
    uint32 frameLengths_us[FRAME_TYPE_NB];
		// ǰ+SFD ʱDW1000 ڲʱ䵥λ
    uint32 storedPreLen;           //precomputed conversion of preamble and sfd in DW1000 time units
		// ǰ+SFD ʱ΢룩
    uint64 storedPreLen_us;		   //precomputed conversion of preamble and sfd in microseconds

// ======================== Ϣṹ建 ============================
    // Ҫ͵֡Щṹ
#if (USING_64BIT_ADDR == 1)
// ʼϢַ  ַ
	srd_msg_dlsl rng_initmsg ;				// ranging init message (destination long, source long)
	// ׼ 802.15.4 ַ֡
    srd_ext_msg_dlsl msg; 					// simple 802.15.4 frame structure (used for tx message) - using long addresses
		// ϢϢͬʱ϶豸б
	srd_ext_msg_dssl inf_msg;         	  	// extended inf message containing frame lengths and slot assignments
    // ϱϢ롢ꡢCSR
		srd_ext_msg_dssl report_msg;          	// extended report message containing the calculated range
    // ͬУ׼Ϣ
		srd_ext_msg_dssl sync_msg;		      	// extended message indicating the need to resync TDMA frame
#else
// Ϣ塿
// UWB֮շָͬࡢϱȫ4ṹ
// ʼϢRNG_INIT
// ã߶ԷҪʼˡʹáַ+̵ַʽ
	srd_msg_dlss rng_initmsg ;  			// ranging init message (destination long, source short)
	// ͨ÷Ϣ֡802.15.4ʽ
// ãͨĶ̵ַͨŰͨ÷ʹ
    srd_ext_msg_dsss msg; 				  	// simple 802.15.4 frame structure (used for tx message) - using short addresses
		// INF ϢϢ
// ã֡͡ȡʱ϶䡢豸Ϣ ͬãǰSUGϢõľ
    srd_ext_msg_dsss inf_msg;         	  	// extended inf message containing frame lengths and slot assignments
		// ϱϢ
// ãɺ󣬰ѡֵ/ڵ
    srd_ext_msg_dsss report_msg;		  	// extended report message containing the calculated range
		// ͬУ׼Ϣ
// ã豸Ҫ¶TDMA֡ʱӡ
    srd_ext_msg_dsss sync_msg;		      	// extended message indicating the need to resync TDMA frame
#endif
// BLINK 㲥Ϣ豸ã
	iso_IEEE_EUI64_blink_msg blinkmsg ; // frame structure (used for tx blink message)

	// ============================ 豸ַ ================================
    // 64λȫΨһӲַ EUI64
	uint8   eui64[8];				// devices EUI 64-bit address
	// 16λ̵ַͨʹã
	uint16  uwbShortAdd;		    // UWB's short address (16-bit) used when USING_64BIT_ADDR == 0
	// ֡кţÿһ֡Զ +1ڶ⣩
    uint8   frameSN;				// modulo 256 frame sequence number - it is incremented for each new frame transmittion
		//  PANIDͬһͬ
	uint16  panID ;					// panid used in the frames
// ַֽڳȣ2ֽ  8ֽڣ
    uint8 addrByteSize;             // The bytelength used for addresses. 
// Ӧʱ
    uint32 resp_dly_us[RESP_DLY_NB];

	// ======================== UWB ʱģ ==========================
    // ê RESP ʱ
	uint64 anchorRespTxTime ;		// anchor's reponse tx timestamp
	// ê RESP ʱ
	uint64 anchorRespRxTime ;	    // receive time of response message
	// ǩ POLL ʱ
	uint64 tagPollRxTime ;          // receive time of poll message
	// FINAL Ϣʱ
	uint64 dwt_final_rx;			// receive time of the final message
	// Latest DS-TWR timing terms packed into RNG_REPORT broadcast payload.
	uint64 lastReportTround1;
	uint64 lastReportTreply1;
	uint64 lastReportTround2;
	uint64 lastReportTreply2;

	//application control parameters
    uint8	wait4ack ;					// if this is set to DWT_RESPONSE_EXPECTED, then the receiver will turn on automatically after TX completion
	uint8	gotTO;						// got timeout event

    // ========================= ״̬ ================================
    // 豸ʱ TOF
    int64 tof[UWB_LIST_SIZE] ;
		// ʱƫֵ
    double clockOffset ;

    //RSL reporting
		// ======================== źǿ RSL  ==============================
    // RSL 
    uint8 rslCnt;
		// RSL 
    uint8 idxRSL;
		// źǿ
    double RSL[NUM_RSL_AVG];
		// ƽźǿ
    double avgRSL;

   // ======================== շ ==================================
    // ֡
	int txmsgcount;
	// ֡
	int	rxmsgcount;
	// ͳʱ
	int lateTX;
	// ճʱ
	int lateRX;
 // ²豸
    uint8 newRangeUWBIndex; //index for most recent ranging exchange
		// ²ǷЧ
    int newRange;
		// ²êַ
    uint64 newRangeAncAddress; //anchor address for most recent ranging exchange
		// ²ıǩַ
    uint64 newRangeTagAddress; //tag address for most recent ranging exchange
// 
    double idistance[UWB_LIST_SIZE];
		// RSL 
    double idistancersl[UWB_LIST_SIZE];
		// ԭʼ
	double idistanceraw[UWB_LIST_SIZE];
	// źǿֵ
	double iRSL[UWB_LIST_SIZE];
// ======================== MESH Ļ =============================
    // Ϣʱ
	uint64 infoMsgRxTimestamp[UWB_LIST_SIZE];
	// ǰϢʱ
	uint64 infoMsgTxTimestampCurrent;
  // ϴηϢʱ
	uint64 infoMsgTxTimestampPrevious;
	 // ġڵ㻺飺豸 CSR X/Y/Z״̬
	mesh_node_cache_t meshNodeCache[UWB_LIST_SIZE];
	// ڵ̵ַ
	uint16 meshMasterShortAddr;
	// ھϢα꣨ã
	uint8 meshInfoNeighborCursor;
	// 㲥α
	uint8 meshResultCursor;
	// ϱϢк
	uint8 meshReportSequence;
	// ֡
	uint32 meshFrameCounter;
	// 㲥
	uint8 meshResultPeriodFrames;
	// ======================== MESH м/תϵͳ ==============================
    // ؼǷдתϢ1=У0=ޣ ֮ǰĸԴ
	uint8 meshPendingRelayValid;
	// תϢ
	uint8 meshPendingRelayPayload[MAX_EXTENDED_USER_PAYLOAD_STRING_SS];
	// תϢ
	uint16 meshPendingRelayLength;
	// תظ
	uint8 meshPendingRelayRepeats;
	// תԴַ
	uint16 meshPendingRelayOrigin;
	// תϢк
	uint8 meshPendingRelaySeq;
	// תϢ
	uint8 meshPendingRelayType;
	// ======================== Ϣȥأظ ==========================
    // Ѵ INFO Ϣ
	uint8 meshLastSeenInfoSeq[UWB_LIST_SIZE];
	// INFO ϢЧ־
	uint8 meshLastSeenInfoValid[UWB_LIST_SIZE];
	// Ѵ RESULT Ϣ
	uint8 meshLastSeenResultSeq[UWB_LIST_SIZE];
	// RESULT ϢЧ־
	uint8 meshLastSeenResultValid[UWB_LIST_SIZE];
// ======================== ھ豸б ===============================
    // ǰҪĿ豸
	uint8 uwbToRangeWith;	//it is the index of the uwbList array which contains the address of the UWB we are ranging with
	// ھ豸
    uint8 uwbListLen ; //ǰھ
		// ھ豸ַб
	uint8 uwbList[UWB_LIST_SIZE][8];		//index 0 reserved for self, rest for other tracked uwbs
// ======================== ͳʱ ===================================
    // ʱ
	uint32 timeofTx;						//used to calculate tx done callback timeouts
	// POLL ʱ
	uint32 timeofTxPoll;                    //used to calculate rx timeout after poll
	// FINAL ʱ
	uint32 timeofTxFinal;                   //used to calculate rx timeout after final
	// ɳʱʱ
	uint32 txDoneTimeoutDuration;			//duration used for tx done callback timeouts. (set differently for each tx message)
 // ======================== ֡ͱ =============================
    // ͵ POLL
	uint8 tx_poll;							//was the last tx message a POLL message?
	// ͵ RESP
	uint8 tx_anch_resp;						//was the last tx message an ANCH_RESP message?
	// ͵ FINAL
	uint8 tx_final;							//was the last tx message a FINAL message?

	// ======================== ж¼ ==================================
    // ¼TX Done / RX Done / ʱ
    event_data_t dwevent[MAX_EVENT_NUMBER]; //this holds any TX/RX events and associated message data
		// ¼ȡָ
    uint8 dweventIdxOut;//¼ һöȡĸ¼
		// ¼дָ
    uint8 dweventIdxIn;
		// ¼͵ȡ
	uint8 dweventPeek; // ͵һµǰʲô¼ǲա
// ======================== ԴӲУ׼ =================================
    // ܽģʽ
	uint8 smartPowerEn;
// ռʱ
	uint32 rxCheckOnTime;
// źŹ
	double rxPWR;
	// У׼
	uint8 acc_adj;
// 8ŵ
	instanceConfig_t chConfig[8];

} instance_data_t ;



//-------------------------------------------------------------------------------------------------------------
//
//	Functions used in logging/displaying range and status data
//
//-------------------------------------------------------------------------------------------------------------

// function to calculate and report the Time of Flight to the GUI/display
double getrangebias_rng(uint8 channel, uint8 prf, double distance);
double getrangebias_rsl(uint8 channel, uint8 prf, double rsl);
int reportTOF(instance_data_t *inst, uint8 uwb_index, double rsl);
// clear the status/ranging data 
void instanceclearcounts(void) ;
void instclearuwblist(void);
int instaddactivateuwbinlist(instance_data_t *inst, uint8 *uwbAddr);
int instcheckactiveuwbinlist(instance_data_t *inst, uint8 *uwbAddr);
int instfindfirstactiveuwbinlist(instance_data_t *inst, uint8 startindex);
int instfindnumactiveuwbinlist(instance_data_t *inst);
int instfindnumneighbors(instance_data_t *inst);
int instfindnumhidden(instance_data_t *inst);
int instgetuwblistindex(instance_data_t *inst, uint8 *uwbAddr, uint8 addrByteSize);


void instance_readaccumulatordata(void);
//-------------------------------------------------------------------------------------------------------------
//
//	Functions used in driving/controlling the ranging application
//
//-------------------------------------------------------------------------------------------------------------
void setupmacframedata(instance_data_t *inst, int fcode);

// Call init, then call config, then call run. call close when finished
// initialise the instance (application) structures and DW1000 device
int instance_init(void);
int instance_init_s(void);
int tdma_init_s(uint64 slot_duration);
int decarangingmode(uint8 mode_switch);

// configure the instance and DW1000 device
void instance_config(instanceConfig_t *config) ;  

void instancerxon(instance_data_t *inst, int delayed, uint64 delayedReceiveTime);
void inst_processtxrxtimeout(instance_data_t *inst);

int instancesendpacket(uint16 length, uint8 txmode, uint32 dtime);

// called (periodically or from and interrupt) to process any outstanding TX/RX events and to drive the ranging application
int instance_run(void) ;       // returns indication of status report change
int testapprun(instance_data_t *inst, struct TDMAHandler *tdma_handler, int message);

// calls the DW1000 interrupt handler
#define instance_process_irq(x) 	dwt_isr()  //call device interrupt handler
// configure TX/RX callback functions that are called from DW1000 ISR
void instance_rxerrorcallback(const dwt_cb_data_t *rxd);
void instance_rxtimeoutcallback(const dwt_cb_data_t *rxd);
void instance_rxgoodcallback(const dwt_cb_data_t *rxd);
void instance_txcallback(const dwt_cb_data_t *txd);
void instance_irqstuckcallback(void);

void instancesetreplydelay(int datalength);

// Pre-compute frame lengths, timeouts and delays needed in ranging process.
// /!\ This function assumes that there is no user payload in the frame.
void instance_init_timings(void);

uint32 instance_getmessageduration_us(int data_length_bytes);

// set/get the instance roles e.g. Tag/Anchor/Listener
int instancegetrole(void) ;
// get the DW1000 device ID (e.g. 0xDECA0130 for MP)
uint32 instancereaddeviceid(void) ;                                 // Return Device ID reg, enables validation of physical device presence

void instancerxon(instance_data_t *inst, int delayed, uint64 delayedReceiveTime);
double instance_get_idist(uint8 uwb_index);
double instance_get_idistrsl(uint8 uwb_index);
double instance_get_idistraw(uint8 uwb_index);
double instance_get_irsl(uint8 uwb_index);
void configure_continuous_txspectrum_mode(void);

uint64 instance_get_addr(void); //get own address (8 bytes)
uint64 instance_get_uwbaddr(uint8 uwb_index); //get uwb address (8 bytes)

uint64 instancenewrangeancadd(void);
uint64 instancenewrangetagadd(void);
int instanceisranging(void);
int instancenewrange(void);
int instancesleeping(void);
int instanceanchorwaiting(void);

int instance_get_rxf(void);
int instance_get_txf(void); //get number of Txed frames

int instance_get_txl(void) ;
int instance_get_rxl(void) ;

uint32 convertmicrosectodevicetimeu32 (double microsecu);
uint64 convertmicrosectodevicetimeu (double microsecu);
double convertdevicetimetosec(int32 dt);
double convertdevicetimetosec8(uint8* dt);

int testapprun_af(instance_data_t *inst, int message);
int testapprun_tf(instance_data_t *inst, int message);

int instance_peekevent(void);

void instance_putevent(event_data_t newevent);

event_data_t* instance_getevent(int x);

void instance_clearevents(void);

// configure the antenna delays
void instanceconfigantennadelays(uint16 tx, uint16 rx);
void instancesetantennadelays(void);
uint16 instancetxantdly(void);
uint16 instancerxantdly(void);

int instance_starttxtest(int framePeriod);

const char* get_instanceModes_string(enum instanceModes mode);
const char* get_discovery_modes_string(enum discovery_modes mode);
const char* get_inst_states_string(enum inst_states state);

instance_data_t* instance_get_local_structure_ptr(unsigned int x);
struct TDMAHandler* tdma_get_local_structure_ptr(void);

uint32 get_dt32(uint32 t1, uint32 t2);
uint32 timestamp_add32(uint32 timestamp, uint32 duration);
uint32 timestamp_subtract32(uint32 timestamp, uint32 duration);
uint64 get_dt64(uint64 t1, uint64 t2);
uint64 timestamp_add64(uint64 timestamp, uint64 duration);
uint64 timestamp_subtract64(uint64 timestamp, uint64 duration);

uint16 address64to16(uint8 *address);

void send_statetousb(instance_data_t *inst, struct TDMAHandler *tdma_handle);
void send_rxmsgtousb(char *data);
void send_txmsgtousb(char *data);
char* get_msg_fcode_string(int fcode);
void debug_print_line(char *line);

#ifdef __cplusplus
}
#endif

#endif
