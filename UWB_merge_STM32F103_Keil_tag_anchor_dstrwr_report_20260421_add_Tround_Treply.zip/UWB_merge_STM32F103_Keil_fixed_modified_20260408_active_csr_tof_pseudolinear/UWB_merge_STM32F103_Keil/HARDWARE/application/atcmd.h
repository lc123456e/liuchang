#ifndef __ATCMD_H
#define __ATCMD_H	 
#include "stm32f10x.h"

#define SW   0x01
#define DECA 0x02
#define VERS 0x03
#define INFO 0x04
#define BATT 0x05
#define SLEP 0x06
#define TEST 0x07
#define STAR 0x08
#define MTAG 0x09
#define RSET 0x0A
#define LPOW 0x0B
#define QSET 0x0C
#define EROR 0x0F


extern u8 SendBuff[200];
extern u8 n; //SendBuff index
extern u8 USB_RxBuff[30];
extern u32 CpuID[3];
u8 Check_cmd(u8* RXbuff);

u8 Transfer_Byte(u8 value);
void Display_Searching(void);
void Display_ATCMDInfo(void);
void Display_UWBInfo(void);
//u8 Check_Switch_Status(u16 value);

void Process_ATCMD(void);
#endif
