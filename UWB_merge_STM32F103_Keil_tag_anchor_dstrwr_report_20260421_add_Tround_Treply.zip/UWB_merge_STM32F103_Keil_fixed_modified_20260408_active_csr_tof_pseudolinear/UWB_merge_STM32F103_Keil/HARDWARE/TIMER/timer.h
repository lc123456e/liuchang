#ifndef __TIMER_H
#define __TIMER_H
#include "stm32f10x.h"

void TIM2_Int_Init(u16 arr,u16 psc);
void Load_timer2_search(void);
extern u8 timer2_sysrun;
extern u8 timer2_cfgrun;//1:waiting for configured
extern u8 timer2_search;
extern u8 timer2_udma_send;
extern int m;
#endif



