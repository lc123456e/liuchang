#ifndef _DEVICE_INFO_H_
#define _DEVICE_INFO_H_
#include "stm32f10x.h"	

typedef struct
{
	u16 flag;
	u16 start_count;
	u16 mode;
	u16 channel;
	u16 datarate;
	u16 uwbid;
	u16 lowpower;
	u16 hw_ver;
	
	u16 power_source;	
	
	
	u16 device_switch;
//	u16 hw_version[4];
//	u16 sw_version[4];
	u16 sleeptime;
} System_Para_TypeDef; 

extern u16 FLAH_BUFF0[16];
extern u8 buff_version[19];
extern u8 buff_sn[41];
extern u8 buff_wifipassword[10];
extern System_Para_TypeDef sys_para;


//u8 Check_cmd(u8* RXbuff);
u8 Get_UniqueID(void);
void Flash_Configuration(void);
u8 RouterInfo_Write_to_Flash(u8 OBJ, u8* buffer);
void My_STMFLASH_Write(void);
u16 GetRecSwtich(u8* RXbuff);
#endif

