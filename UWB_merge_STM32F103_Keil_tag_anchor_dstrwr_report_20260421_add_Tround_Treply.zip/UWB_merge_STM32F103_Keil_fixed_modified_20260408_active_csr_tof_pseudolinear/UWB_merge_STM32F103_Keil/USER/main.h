#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>
#include <string.h>
#include <math.h>

#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "spi.h"
#include "port.h"
#include "instance.h"
#include "deca_types.h"
#include "deca_spi.h"
#include "device_info.h"
#include "stmflash.h"
#include "dma.h"
#include "hw_config.h"
#include "timer.h"
#include "adc.h"
#include "rtc.h"
#include "iwdg.h"
#include "wkup.h"
#include "atcmd.h"

uint32 inittestapplication(uint8 mode_switch);

#endif /* MAIN_H_ */
