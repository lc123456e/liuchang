
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'SPI' 
 * Target:  'TREK1000' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f10x.h"

/* Keil::Device:StdPeriph Drivers:ADC@3.6.0 */
#define RTE_DEVICE_STDPERIPH_ADC
/* Keil::Device:StdPeriph Drivers:BKP@3.6.0 */
#define RTE_DEVICE_STDPERIPH_BKP
/* Keil::Device:StdPeriph Drivers:DMA@3.6.0 */
#define RTE_DEVICE_STDPERIPH_DMA
/* Keil::Device:StdPeriph Drivers:EXTI@3.6.0 */
#define RTE_DEVICE_STDPERIPH_EXTI
/* Keil::Device:StdPeriph Drivers:Flash@3.6.0 */
#define RTE_DEVICE_STDPERIPH_FLASH
/* Keil::Device:StdPeriph Drivers:Framework@3.6.0 */
#define RTE_DEVICE_STDPERIPH_FRAMEWORK
/* Keil::Device:StdPeriph Drivers:GPIO@3.6.0 */
#define RTE_DEVICE_STDPERIPH_GPIO
/* Keil::Device:StdPeriph Drivers:IWDG@3.6.0 */
#define RTE_DEVICE_STDPERIPH_IWDG
/* Keil::Device:StdPeriph Drivers:PWR@3.6.0 */
#define RTE_DEVICE_STDPERIPH_PWR
/* Keil::Device:StdPeriph Drivers:RCC@3.6.0 */
#define RTE_DEVICE_STDPERIPH_RCC
/* Keil::Device:StdPeriph Drivers:RTC@3.6.0 */
#define RTE_DEVICE_STDPERIPH_RTC
/* Keil::Device:StdPeriph Drivers:SPI@3.6.0 */
#define RTE_DEVICE_STDPERIPH_SPI
/* Keil::Device:StdPeriph Drivers:TIM@3.6.0 */
#define RTE_DEVICE_STDPERIPH_TIM
/* Keil::Device:StdPeriph Drivers:USART@3.6.0 */
#define RTE_DEVICE_STDPERIPH_USART
/* Keil::Device:StdPeriph Drivers:WWDG@3.6.0 */
#define RTE_DEVICE_STDPERIPH_WWDG


#endif /* RTE_COMPONENTS_H */
